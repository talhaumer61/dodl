# PayFast CS-CART Plugin
PayFast plugin for CS CART

- Go to CS CART Admin.
- Go to Addons options.
- Click on '+' sign to upload plugin files.
- Select PayFast from the addons list to provide merchant configurations.
- Alternatively, extract the zip archive into CS-CART root.


PayFast Tech Team
https://gopayfast.com
